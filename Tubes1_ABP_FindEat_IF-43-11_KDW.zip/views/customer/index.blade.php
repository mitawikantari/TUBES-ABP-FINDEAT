@extends('customer')

@section('content')
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand text-white" href="#">FindEat</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarText">
        <span class="navbar-text ml-auto">
            Akun
        </span>
    </div>

</nav>

<div class="container-fluid banner-home" style="background:url('{{ asset('img/banner-home.png') }}');">
    <div class="d-block justify-content-center col-md-6 m-auto text-center pt-5">
        <h1>FindEat!</h1>
        <h3>Find the best food and drink in bandung </h3>
        <div class="input-group my-3">
            <input type="text" class="form-control text-center" placeholder="Cari Sesuatu">
        </div>
    </div>
</div>

<div class="container margin-min-30">
    <div class="card">
        <div class="card-body">
            <!-- collection -->
            <div class="d-flex justify-content-between">
                <div>
                    <h5 class="mb-0">Collections</h5>
                    <span>Explore many restaurants in Bandung</span>
                </div>
                <a href="nav-link" class="align-self-center">See all collections</a>
            </div>

            <div class="row mt-3">
                <div class="col-md-3">
                    <img src="{{ asset('img/assets/collection-1.png') }}" class="img-fluid mb-3">
                </div>
                <div class="col-md-3">
                    <img src="{{ asset('img/assets/collection-2.png') }}" class="img-fluid mb-3">
                </div>
                <div class="col-md-3">
                    <img src="{{ asset('img/assets/collection-3.png') }}" class="img-fluid mb-3">
                </div>
                <div class="col-md-3">
                    <img src="{{ asset('img/assets/collection-4.png') }}" class="img-fluid mb-3">
                </div>
            </div>

            <!-- Popular Localities in and around Bandung -->
        </div>
    </div>
</div>
@endsection